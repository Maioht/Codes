# Chat-Javascript

Small chat project.

-Server side and client side made at javascript using socket.io library.

-Users log and register and this information is saved using mongodb

-its only skeleton but works.
