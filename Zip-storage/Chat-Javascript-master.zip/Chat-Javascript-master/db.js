//database url

exports.getDbUrl = () => `mongodb://localhost:27017/chatDB`;