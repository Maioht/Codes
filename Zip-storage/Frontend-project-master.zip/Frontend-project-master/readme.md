
Project - (HTML/CSS/javascript)

Simple web page -> home and blog page.

bootstrap -> https://getbootstrap.com/

nodejs -> https://nodejs.org/en/

express -> https://expressjs.com/

axios -> https://github.com/axios/axios

body-parser -> https://www.npmjs.com/package/body-parser


The blog page is included the greetings (comment) section, the comments are saved json file.
 
Todo: 
-insert timestamp and show only five latest greetings post. 
-adjust some appereance, now this is only to show how to do simple front-end website fast. 




