Weatherapp 

Simple weather app which fetches weather information.

-Java, Spring Boot

-Reactjs framework. 

-problems: to find website where can get information easy, many weather information providing websites wants registration and free calls are limited.


