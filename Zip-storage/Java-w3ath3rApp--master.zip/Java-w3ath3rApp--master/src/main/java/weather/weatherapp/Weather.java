package weather.weatherapp;

public class Weather extends WeatherEntry {
    private String name;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
