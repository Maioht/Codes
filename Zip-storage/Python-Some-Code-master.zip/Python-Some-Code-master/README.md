# Python-Some-Code

Some basic python coding 
