import React from 'react';

const Template = props => {
    return (
        <div style={{
            backgroundColor: "f4f6ff",
            position: "fixed",
            width: "100%",
            height: "100%",
            display: "inline-block",
            zIndex:"-1"
        }}>
        </div>
    );
}

export default Template;