simple Spotify control Panel. 

At first visit : https://developer.spotify.com/documentation/general/guides/app-settings/

there's  some instructions starting and giving permissions for spotify web development 

Some notes:

Buttons works only when user is premium user. 

Features:

*shows what your spotify is playing in your (using your account) speakers
*can play previous, paused, play and play next. (premium users only)


