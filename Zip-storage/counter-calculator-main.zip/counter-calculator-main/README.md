
simply javascript program for network speed calculation for device

Run program in nodeJs. <node main.js>

There are two functions to calculate speed and distance.
main program makes       Cancel changes

  
  main.js : includes main program and Functions calculates network speed and device distance.

  The calculation is run in the main program, which prints the desired information.



Unit Test:
unit testing has been done using the Jest framework.

Simply tested how the functions work. The unit tests pass, but changing the values (main.test.js) can fail
